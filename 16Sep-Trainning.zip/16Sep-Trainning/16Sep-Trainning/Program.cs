﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16Sep_Trainning
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine("Enter The Number of Entres you want To Add");
            // int num=int.Parse(Console.ReadLine());
            //FruitsByAscending.Execute();
            //NoOfDaysinmonth.Execute();
            //WAPDate.Execute();
            FileHandling.Execute();
          
            
        }
    }
}
